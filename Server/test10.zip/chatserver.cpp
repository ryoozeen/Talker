#include "chatserver.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QDateTime>
#include <QHostAddress>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include "dbutil.h"

ChatServer::ChatServer(QObject *parent) : QTcpServer(parent) {}


void ChatServer::incomingConnection(qintptr handle) {
    auto s = new QTcpSocket(this);
    s->setSocketDescriptor(handle);
    connect(s, &QTcpSocket::readyRead, this, &ChatServer::onReadyRead);
    connect(s, &QTcpSocket::disconnected, this, &ChatServer::onDisconnected);
    qInfo() << "client connected:" << s->peerAddress().toString() << s->peerPort();
}

void ChatServer::onReadyRead() {
    auto s = qobject_cast<QTcpSocket*>(sender());
    if (!s) return;
    while (s->canReadLine()) {
        const auto line = s->readLine().trimmed();
        if (!line.isEmpty()) handleLine(s, line);
    }
}

void ChatServer::onDisconnected() {
    auto s = qobject_cast<QTcpSocket*>(sender());
    if (!s) return;
    const auto id = idBySocket_.take(s);
    if (!id.isEmpty()) socketById_.remove(id);
    s->deleteLater();
    qInfo() << "client disconnected" << id;
}

// 같은 방의 두 사용자 모두에게 obj를 전송
void ChatServer::sendToRoomBoth(qint64 roomId, const QJsonObject& obj)
{
    QSqlQuery q(DbUtil::getDB());
    q.prepare("SELECT user_a, user_b FROM dm_rooms WHERE room_id=? LIMIT 1");
    q.addBindValue(roomId);
    if (!q.exec() || !q.next()) return;

    const QString a = q.value(0).toString();
    const QString b = q.value(1).toString();

    auto sendTo = [&](const QString& id) {
        if (QTcpSocket* s = socketById_.value(id, nullptr)) {
            s->write(QJsonDocument(obj).toJson(QJsonDocument::Compact) + "\n");
        }
    };
    sendTo(a);
    sendTo(b);
}

void ChatServer::handleStatusNotify(QTcpSocket* s, const QJsonObject& obj)
{
    const QString me = idBySocket_.value(s);
    if (me.isEmpty()) return;

    const QString status = obj.value("status").toString().left(255);

    // (선택) 서버에서도 DB 반영 — 클라가 이미 저장했어도 안전하게 맞춰줌
    {
        QSqlQuery up(DbUtil::getDB());
        up.prepare(R"SQL(
            INSERT INTO user_profile(login_id, status_message)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE
              status_message = VALUES(status_message),
              updated_at     = CURRENT_TIMESTAMP
        )SQL");
        up.addBindValue(me);
        up.addBindValue(status);
        if (!up.exec()) {
            qWarning() << "[status upsert fail]" << up.lastError().text();
        }
    }

    // 나를 구독하는(=나를 친구로 등록해 둔) 사람들 찾기
    QSqlQuery q(DbUtil::getDB());
    q.prepare(R"SQL(
        SELECT owner_id AS target
        FROM friends
        WHERE friend_id = ?
        UNION
        SELECT friend_id AS target
        FROM friends
        WHERE owner_id = ?   -- 양방향 저장 안 된 경우를 대비해 추가
    )SQL");
    q.addBindValue(me);
    q.addBindValue(me);
    if (!q.exec()) {
        qWarning() << "[status notify] query fail:" << q.lastError().text();
        return;
    }

    QJsonObject push{
                     {"type",     "S2C_FRIEND_STATUS_CHANGED"},
                     {"login_id", me},
                     {"status",   status},
                     };
    const QByteArray bytes = QJsonDocument(push).toJson(QJsonDocument::Compact) + "\n";

    int cnt = 0;
    while (q.next()) {
        const QString target = q.value(0).toString();
        if (QTcpSocket* t = socketById_.value(target, nullptr)) {
            t->write(bytes);
            ++cnt;
        }
    }
    qInfo() << "[status_notify]" << me << "-> broadcast:" << cnt;
}

void ChatServer::handleLine(QTcpSocket* s, const QByteArray& line) {
    const auto obj = QJsonDocument::fromJson(line).object();
    const QString type = obj.value("type").toString();

    if (type == "login") {
        const QString loginId = obj.value("login_id").toString();
        idBySocket_[s] = loginId;
        socketById_[loginId] = s;
        qInfo() << "login:" << loginId;
        return;
    }

    // 상태메세지 변경 알림 처리
    if (type == "status_notify" || type == "C2S_STATUS_NOTIFY") {
        handleStatusNotify(s, obj);
        return;
    }

    // 공통 추출: 보낸 사람은 클라이언트 JSON이 아니라 서버가 기억한 ID로!
    const qint64 roomId = static_cast<qint64>(obj.value("room_id").toDouble());
    const QString sender = idBySocket_.value(s);   // ⬅️ 신뢰 가능한 보낸 사람
    const QString text   = obj.value("text").toString();

    if (type == "chat") {
        // 1) DB 저장
        QString err;
        if (!DbUtil::insertMessage(roomId, sender, text, &err)) {
            qWarning() << "insertMessage failed:" << err;
        }

        // 2) 상대에게만 전달(보낸 사람 화면은 클라이언트가 이미 바로 그려줌)
        const QString peer = DbUtil::peerInRoom(roomId, sender);
        if (!peer.isEmpty()) {
            if (auto ps = socketById_.value(peer, nullptr)) {
                QJsonObject out{
                    {"type","chat"},
                    {"room_id", static_cast<double>(roomId)},
                    {"sender", sender},
                    {"text", text},
                    {"ts", QDateTime::currentDateTime().toString(Qt::ISODate)}
                };
                ps->write(QJsonDocument(out).toJson(QJsonDocument::Compact) + "\n");
            }
        }
        return;
    }
    else if (type == "enter") {
        // "입장하셨습니다" 도장 찍기 (요구사항: 저장 권장)
        QString err;
        if (!DbUtil::insertMessage(roomId, sender, text, &err)) {
            qWarning() << "insert enter failed:" << err;
        }

        // 양쪽 모두에게 브로드캐스트(보낸 사람 화면에도 즉시 보이게)
        QJsonObject out{
            {"type","enter"},
            {"room_id", static_cast<double>(roomId)},
            {"sender", sender},
            {"text", text},
            {"ts", QDateTime::currentDateTime().toString(Qt::ISODate)}
        };
        sendToRoomBoth(roomId, out);
        return;
    }
}
