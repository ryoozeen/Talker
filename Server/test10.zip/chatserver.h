#ifndef CHATSERVER_H
#define CHATSERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QHash>
#include <QJsonObject>     // ⬅️ 없으면 추가

class ChatServer : public QTcpServer {
    Q_OBJECT
public:
    explicit ChatServer(QObject* parent=nullptr);

protected:
    void incomingConnection(qintptr handle) override;

private slots:
    void onReadyRead();
    void onDisconnected();

private:
    QHash<QTcpSocket*, QString> idBySocket_;  // socket -> login_id
    QHash<QString, QTcpSocket*> socketById_;  // login_id -> socket

    void handleLine(QTcpSocket* s, const QByteArray& line);
    // ⬇️ 추가: 같은 방의 두 사용자 모두에게 보내는 헬퍼
    void sendToRoomBoth(qint64 roomId, const QJsonObject& obj);

    // ★ 추가: 상태메세지 변경 알림 처리
    void handleStatusNotify(QTcpSocket* s, const QJsonObject& obj);

    // ★ (옵션) 편의: 특정 로그인ID에게 푸시
    inline void pushTo(const QString& loginId, const QJsonObject& obj) {
        if (auto t = socketById_.value(loginId, nullptr)) {
            t->write(QJsonDocument(obj).toJson(QJsonDocument::Compact) + "\n");
        }
    }
};

#endif // CHATSERVER_H
