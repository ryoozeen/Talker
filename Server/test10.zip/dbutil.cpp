#include "dbutil.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <QDebug>
#include <QProcessEnvironment>

static QString kConnName = "chatserver_mysql";

QSqlDatabase DbUtil::getDB() {
    return db();   // private 함수 db()를 호출해서 반환
}

QSqlDatabase DbUtil::db() {
    return QSqlDatabase::database(kConnName);
}

bool DbUtil::connectFromEnv() {
    if (QSqlDatabase::contains(kConnName)) return true;
    QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
    const QString host = env.value("DB_HOST","127.0.0.1");
    const QString name = env.value("DB_NAME","talker");
    const QString user = env.value("DB_USER","root");
    const QString pass = env.value("DB_PASS","");
    QSqlDatabase d = QSqlDatabase::addDatabase("QMYSQL", kConnName);
    d.setHostName(host);
    d.setDatabaseName(name);
    d.setUserName(user);
    d.setPassword(pass);
    if (!d.open()) {
        qWarning() << "DB open failed:" << d.lastError().text();
        return false;
    }
    return true;
}

bool DbUtil::insertMessage(qint64 roomId, const QString& sender, const QString& body, QString* err) {
    QSqlQuery q(db());
    q.prepare("INSERT INTO messages(room_id, sender_login_id, body) VALUES (?,?,?)");
    q.addBindValue(roomId);
    q.addBindValue(sender);
    q.addBindValue(body);
    if (!q.exec()) {
        if (err) *err = q.lastError().text();
        return false;
    }
    return true;
}

QString DbUtil::peerInRoom(qint64 roomId, const QString& sender) {
    QSqlQuery q(db());
    q.prepare(R"(
        SELECT CASE WHEN user_a = ? THEN user_b ELSE user_a END AS peer
        FROM dm_rooms
        WHERE room_id = ? LIMIT 1
    )");
    q.addBindValue(sender);
    q.addBindValue(roomId);
    if (!q.exec()) return QString();
    if (q.next()) return q.value(0).toString();
    return QString();
}
