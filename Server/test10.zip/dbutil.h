#ifndef DBUTIL_H
#define DBUTIL_H

#include <QString>
#include <QSqlDatabase>
#include <QVariantMap>
#include <QList>

class DbUtil {
public:
    static bool connectFromEnv(); // uses DB_HOST, DB_NAME, DB_USER, DB_PASS
    static bool insertMessage(qint64 roomId, const QString& sender, const QString& body, QString* err);
    static QString peerInRoom(qint64 roomId, const QString& sender);
    static QSqlDatabase getDB();   // 참조(&) 제거!  값 반환으로 선언


private:
    static QSqlDatabase db();
};

#endif // DBUTIL_H
