#include <QCoreApplication>
#include <QCommandLineParser>
#include <QHostAddress>
#include "chatserver.h"
#include "dbutil.h"

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName("TalkerChatServer");
    QCoreApplication::setOrganizationName("Talker");

    QCommandLineParser parser;
    parser.addHelpOption();
    QCommandLineOption hostOpt({"H","host"}, "Listen host (default 0.0.0.0)", "host", "0.0.0.0");
    QCommandLineOption portOpt({"p","port"}, "Listen port (default 5555)", "port", "5555");
    parser.addOption(hostOpt);
    parser.addOption(portOpt);
    parser.process(app);

    // DB 연결 (환경변수 또는 기본값)
    if (!DbUtil::connectFromEnv()) {
        qCritical() << "DB connect failed. Set env: DB_HOST, DB_NAME, DB_USER, DB_PASS";
        return 1;
    }

    ChatServer server;
    const auto host = QHostAddress(parser.value(hostOpt));
    const quint16 port = parser.value(portOpt).toUShort();
    if (!server.listen(host, port)) {
        qCritical() << "Listen failed:" << server.errorString();
        return 1;
    }
    qInfo() << "ChatServer listening on" << host.toString() << port;

    return app.exec();
}